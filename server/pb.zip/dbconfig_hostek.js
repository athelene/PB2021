const config = {
    user: 'athelenepb',
    password: 'Off 2 find ColdFusion!',
    server: 'sql1-p2stl.ezhostingserver.com',
    database: 'PB2021',
    options: {
        Encrypt: true,
        trustServerCertificate: true
//        enableArithPort: true
    },
    port: 1433
}

module.exports = config;